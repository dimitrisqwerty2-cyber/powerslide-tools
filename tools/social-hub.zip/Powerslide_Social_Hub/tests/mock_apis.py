"""A stand-in for X, Facebook and Instagram, so the hub can be tested without anything going live.

python tests/mock_apis.py [port]
It holds the hub to the rules in the real docs: signed X requests, a Bearer token on Meta calls, Instagram only
taking JPEGs of the right shape from an address Facebook handed out. GET /__log shows every call, and
GET /__fail?key=...&mode=error|drop makes the next call of that kind go wrong."""
import email.parser, email.policy, io, json, os, re, sys, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import platforms as P
from PIL import Image

KEYS = {'api_key': 'test-key', 'api_secret': 'test-secret', 'access_token': 'test-token', 'access_secret': 'test-token-secret'}
USER_TOKEN, PAGE_TOKEN, PAGE, IG = 'long-user-token', 'page-token', '1111', '2222'
LOG, FAIL, PHOTOS, CONTAINERS, MEDIA = [], {}, {}, {}, {}
COUNT = [100]

def next_id():
    COUNT[0] += 1
    return str(COUNT[0])

def parts(handler, raw):
    msg = email.parser.BytesParser(policy=email.policy.HTTP).parsebytes(b'Content-Type: ' + handler.headers['Content-Type'].encode() + b'\r\n\r\n' + raw)
    return {p.get_param('name', header='content-disposition'): p.get_payload(decode=True) for p in msg.iter_parts()}

class Mock(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *a): pass

    def send(self, data, code=200):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def fail(self, key):
        mode = FAIL.pop(key, None)
        if mode == 'drop':
            self.close_connection = True
            self.connection.close()
            return True
        if mode == 'error':
            self.send({'error': {'message': f'mock failure for {key}', 'code': 1}, 'detail': f'mock failure for {key}'}, 400)
            return True

    def handle_any(self, method):
        u = urllib.parse.urlparse(self.path)
        path, query = u.path, dict(urllib.parse.parse_qsl(u.query))
        raw = self.rfile.read(int(self.headers.get('Content-Length') or 0))
        if path == '/__log': return self.send(LOG)
        if path == '/__fail':
            FAIL[query['key']] = query.get('mode', 'error')
            return self.send({'ok': True})
        if path.startswith('/2/'): return self.x(method, path, query, raw)
        if path.startswith('/ig-api-upload/'): return self.rupload(path, raw)
        return self.meta(method, path.removeprefix('/v26.0'), query, raw)

    def do_GET(self): self.handle_any('GET')
    def do_POST(self): self.handle_any('POST')
    def do_DELETE(self): self.handle_any('DELETE')

    # ---------------------------- X
    def x(self, method, path, query, raw):
        auth = self.headers.get('Authorization', '')
        got = dict(re.findall(r'(\w+)="([^"]*)"', auth))
        url = f'http://{self.headers["Host"]}{path}'
        want = P.oauth1_header(method, url, KEYS, query, urllib.parse.unquote(got.get('oauth_nonce', '')), got.get('oauth_timestamp'))
        if dict(re.findall(r'(\w+)="([^"]*)"', want)).get('oauth_signature') != got.get('oauth_signature'):
            return self.send({'title': 'Unauthorized', 'detail': 'bad signature'}, 401)
        LOG.append({'x': path, 'method': method})
        if path == '/2/users/me': return self.send({'data': {'id': '42', 'username': 'PowerslideMedia', 'name': 'Powerslide Media'}})
        if path == '/2/media/upload' and method == 'POST':
            p = parts(self, raw)
            assert p.get('media_category') == b'tweet_image' and len(p['media']) <= 5 * P.MB
            return self.send({'data': {'id': next_id(), 'media_key': 'k'}})
        if path == '/2/media/upload/initialize':
            d = json.loads(raw)
            mid = next_id()
            MEDIA[mid] = {'total': d['total_bytes'], 'got': 0, 'polls': 0}
            return self.send({'data': {'id': mid, 'expires_after_secs': 86400}})
        m = re.fullmatch(r'/2/media/upload/(\d+)/(append|finalize)', path)
        if m and m.group(2) == 'append':
            MEDIA[m.group(1)]['got'] += len(parts(self, raw)['media'])
            return self.send({'data': {'expires_at': 0}})
        if m:
            v = MEDIA[m.group(1)]
            if v['got'] != v['total']: return self.send({'detail': 'short upload'}, 400)
            return self.send({'data': {'id': m.group(1), 'processing_info': {'state': 'pending', 'check_after_secs': 1}}})
        if path == '/2/media/upload':
            v = MEDIA[query['media_id']]
            v['polls'] += 1
            return self.send({'data': {'id': query['media_id'], 'processing_info': {'state': 'succeeded' if v['polls'] > 1 else 'in_progress', 'check_after_secs': 1}}})
        if path == '/2/tweets':
            if self.fail('x_post'): return
            d = json.loads(raw)
            if len(d.get('media', {}).get('media_ids', [])) > 4: return self.send({'detail': 'too many'}, 400)
            LOG[-1]['body'] = d
            return self.send({'data': {'id': next_id(), 'text': d.get('text', '')}}, 201)
        self.send({'detail': 'unknown path'}, 404)

    # ---------------------------- Meta
    def meta(self, method, path, query, raw):
        auth = self.headers.get('Authorization', '')
        form = {}
        kind = self.headers.get('Content-Type', '')
        if kind.startswith('multipart'): form = parts(self, raw)
        elif raw: form = dict(urllib.parse.parse_qsl(raw.decode()))
        text = {k: v.decode() if isinstance(v, bytes) and k != 'source' else v for k, v in form.items()}
        LOG.append({'meta': path, 'method': method, 'fields': {k: v for k, v in text.items() if k != 'source'}})
        if path == '/oauth/access_token': return self.send({'access_token': USER_TOKEN})
        if path == '/debug_token': return self.send({'data': {'expires_at': 0}})
        if path == '/me/accounts':
            return self.send({'data': [{'id': PAGE, 'name': 'Powerslide', 'access_token': PAGE_TOKEN, 'instagram_business_account': {'id': IG, 'username': 'powerslidemedia'}}]})
        if auth != f'Bearer {PAGE_TOKEN}': return self.send({'error': {'message': 'bad token', 'code': 190}}, 400)
        if path == f'/{PAGE}/photos':
            if self.fail('fb_photo'): return
            pid = next_id()
            published = text.get('published') != 'false'
            PHOTOS[pid] = form['source']
            return self.send({'id': pid, 'post_id': f'{PAGE}_{pid}'} if published else {'id': pid})
        if path == f'/{PAGE}/feed':
            if self.fail('fb_feed'): return
            return self.send({'id': f'{PAGE}_{next_id()}'})
        if path == f'/{PAGE}/videos': return self.send({'id': next_id()})
        if path == f'/{IG}/media': return self.ig_container(text)
        if path == f'/{IG}/media_publish':
            if self.fail('ig_publish'): return
            c = CONTAINERS.get(text.get('creation_id'))
            if not c or c['status'] != 'FINISHED': return self.send({'error': {'message': 'media is not ready', 'code': 9007}}, 400)
            return self.send({'id': next_id()})
        if path == f'/{IG}/content_publishing_limit': return self.send({'data': [{'quota_usage': 2, 'config': {'quota_total': 50}}]})
        m = re.fullmatch(r'/(\d+)', path)
        if m:
            i = m.group(1)
            if method == 'DELETE':
                PHOTOS.pop(i, None)
                return self.send({'success': True})
            if i in CONTAINERS: return self.send({'status_code': CONTAINERS[i]['status'], 'id': i})
            if i in PHOTOS: return self.send({'images': [{'width': 100, 'source': 'http://bad'}, {'width': 1000, 'source': f'https://cdn.example/{i}.jpg?oh=a&oe=b'}]})
            if query.get('fields') == 'permalink': return self.send({'permalink': f'https://www.instagram.com/p/{i}/'})
            return self.send({'name': 'Powerslide'})
        self.send({'error': {'message': 'unknown path ' + path}}, 404)

    def ig_container(self, f):
        cid = next_id()
        if f.get('upload_type') == 'resumable':
            CONTAINERS[cid] = {'status': 'IN_PROGRESS', 'kind': f.get('media_type')}
            return self.send({'id': cid, 'uri': f'http://{self.headers["Host"]}/ig-api-upload/v26.0/{cid}'})
        if f.get('media_type') == 'CAROUSEL':
            for k in f['children'].split(','):
                if CONTAINERS.get(k, {}).get('status') != 'FINISHED': return self.send({'error': {'message': 'child not ready'}}, 400)
            CONTAINERS[cid] = {'status': 'FINISHED', 'kind': 'CAROUSEL'}
            return self.send({'id': cid})
        m = re.fullmatch(r'https://cdn\.example/(\d+)\.jpg\?oh=a&oe=b', f.get('image_url', ''))
        if not m or m.group(1) not in PHOTOS: return self.send({'error': {'message': 'cannot fetch image_url', 'code': 9004}}, 400)
        im = Image.open(io.BytesIO(PHOTOS[m.group(1)]))
        r = im.width / im.height
        story = f.get('media_type') == 'STORIES'
        if im.format != 'JPEG' or im.mode != 'RGB' or im.width > 1440 or len(PHOTOS[m.group(1)]) > 8 * P.MB or (not story and not 0.795 <= r <= 1.915):
            return self.send({'error': {'message': f'bad image {im.format} {im.size}', 'code': 36003}}, 400)
        CONTAINERS[cid] = {'status': 'FINISHED', 'kind': f.get('media_type', 'IMAGE'), 'size': im.size}
        LOG[-1]['size'] = im.size
        self.send({'id': cid})

    def rupload(self, path, raw):
        cid = path.rsplit('/', 1)[1]
        size = int(self.headers.get('file_size', -1))
        LOG.append({'rupload': cid, 'bytes': len(raw)})
        if self.headers.get('Authorization') != f'OAuth {PAGE_TOKEN}' or self.headers.get('offset') != '0' or size != len(raw):
            return self.send({'success': False, 'error': {'message': 'bad upload'}}, 400)
        CONTAINERS[cid]['status'] = 'FINISHED'
        self.send({'success': True, 'message': 'Upload successful.'})

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8798
    print(f'Mock X and Meta at http://127.0.0.1:{port}', flush=True)
    ThreadingHTTPServer(('127.0.0.1', port), Mock).serve_forever()
