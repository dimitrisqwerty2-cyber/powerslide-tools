@echo off
rem Powerslide Social Hub: cross-post to X, Facebook and Instagram. Keep this window open, scheduled posts need it.
cd /d "%~dp0"
set PYTHONIOENCODING=utf8
python hub.py
pause
