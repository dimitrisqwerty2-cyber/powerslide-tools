# Powerslide Social Hub

Write one post and send it to X, your Facebook Page and Instagram from one place.

Double-click **Social Hub.bat**. It opens at http://127.0.0.1:8776. Keep the black window open while you use it.

## Getting started

1. The hub starts in **test mode**, shown at the top right. Everything works, but nothing is posted.
2. Open **Accounts** and follow the steps for X, and for Facebook and Instagram.
3. Press the test mode button at the top right to go live.

## What it does

- One main text, with an optional separate text for each platform.
- Your newest graphics from `Pictures\Powerslide Graphics` go in with one click. Drag files in or paste them as well.
- Previews for all three platforms, plus X's own character count and post price.
- Instagram posts, carousels, Reels and Stories. Pictures are fitted to Instagram's shape, with blurred edges or a crop.
- Drafts, scheduling, and a history with links to the live posts.
- If one platform fails, the others still go out and Retry only re-sends the one that failed.
- **Copy and open** in the previews copies the text and opens the site, so you can post by hand for free.

## Good to know

- **X costs money.** X has no free posting now: $0.015 a post, or $0.20 if the post has a link in it. The hub shows the price before you post.
- **Facebook means a Page.** Meta does not let apps post to personal profiles.
- **Instagram must be a Business or Creator account** linked to your Facebook Page.
- **Scheduled posts need this PC on and the hub open.** A post more than 15 minutes late is held in the Queue under Missed, so nothing goes out at the wrong time.
- **X threads are not included.** X limited replies through its API in February 2026 and its docs do not say whether replying to your own post is still allowed.

## Your keys

They are saved in `data\secrets.bin`, encrypted so only your Windows account can read them. They are never sent to the browser page. The hub only listens on this PC and refuses requests from other websites. Don't publish the `data` folder or put it on the public tools site.

## If something goes wrong

| What you see | What to do |
| --- | --- |
| X says the app cannot post | Set the app to Read and Write, then generate a new Access Token. |
| X credit has run out | Top up in the X developer console. |
| Facebook sign-in expired | Make a new token and connect again on the Accounts page. |
| Instagram could not fetch the picture | See below. |
| "Not sure" on a post | Look at the page first. Only post again if it isn't there. |
| Facebook posts only visible to you | The app is in Development mode. Switch it to Live. |

Instagram only fetches pictures from a public web address. The hub puts each picture on your Page as a hidden photo, gives Instagram that address, then deletes the photo. Videos go straight from this PC.

## Testing

`python tests/test_hub.py` runs every posting path against a fake X and Meta in `tests/mock_apis.py`. Nothing goes online.
