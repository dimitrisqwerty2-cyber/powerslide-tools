"""Everything that talks to X, Facebook and Instagram, plus getting pictures into the shape each one wants.

Checked against docs.x.com and developers.facebook.com on 2026-11-01:
X      OAuth 1.0a user keys, POST /2/media/upload (pictures), the initialize/append/finalize upload (video), POST /2/tweets.
Meta   one Page token does both, because Instagram goes through "Instagram API with Facebook Login".
       Instagram only fetches pictures from a public address, so each picture is first put on the Page as an
       unpublished photo, Instagram is given that address, and the photo is deleted once the post is out.
       Video goes straight from this PC through rupload.facebook.com, so it needs no public address."""
import base64, hashlib, hmac, json, os, re, time, unicodedata, uuid
import urllib.error, urllib.parse, urllib.request
from PIL import Image, ImageCms, ImageFilter, ImageOps

X_API = 'https://api.x.com'
GRAPH = 'https://graph.facebook.com/v26.0'
GRAPH_VIDEO = 'https://graph-video.facebook.com/v26.0'
AGENT = 'PowerslideSocialHub/1.0'
X_CHUNK = 4 * 1024 * 1024                 # the docs say to stay at or below 5 MB a segment
MB = 1024 * 1024

def use_mock(base):
    """Sends every call to tests/mock_apis.py instead of the real services."""
    global X_API, GRAPH, GRAPH_VIDEO
    X_API, GRAPH, GRAPH_VIDEO = base, base + '/v26.0', base + '/v26.0'

class PostError(Exception):
    """unsure=True means the post may have gone out anyway, so it must not be retried blindly."""
    def __init__(self, message, unsure=False):
        super().__init__(message)
        self.unsure = unsure

MAYBE_OUT = 'The connection dropped right as this was posting, so it may or may not have gone out. Have a look at the page before trying again.'

def http(method, url, headers=None, body=None, timeout=180, final=False):
    h = {'User-Agent': AGENT}
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw, status = r.read(), r.status
    except urllib.error.HTTPError as e:
        raw, status = e.read(), e.code
    except (urllib.error.URLError, OSError) as e:
        if final: raise PostError(MAYBE_OUT, unsure=True)
        raise PostError(f'Could not reach the server ({getattr(e, "reason", e)}). Is the internet connection up?')
    if final and status >= 500: raise PostError(MAYBE_OUT, unsure=True)
    try: return status, json.loads(raw) if raw else {}
    except ValueError: return status, {'raw': raw[:300].decode('utf8', 'replace')}

def multipart(fields, files):
    """files = {name: (filename, bytes, mime)}. Returns (body, content type)."""
    mark = uuid.uuid4().hex
    out = []
    for k, v in fields.items():
        out += [f'--{mark}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode('utf8')]
    for k, (name, data, mime) in files.items():
        out += [f'--{mark}\r\nContent-Disposition: form-data; name="{k}"; filename="{name}"\r\nContent-Type: {mime}\r\n\r\n'.encode('utf8'), data, b'\r\n']
    out.append(f'--{mark}--\r\n'.encode('utf8'))
    return b''.join(out), f'multipart/form-data; boundary={mark}'

# ---------------------------------------------------------------- counting

URL_RE = re.compile(r'(?:https?://[^\s]+|\b(?:[a-z0-9-]+\.)+(?:com|net|org|gr|io|co|tv|me|info|eu|uk|ee|app|dev|ly|gg)(?:/[^\s]*)?)', re.I)
EMOJI_RE = re.compile('[\U0001F1E6-\U0001F1FF]{2}|[\U0001F000-\U0001FAFF☀-➿](?:️|[\U0001F3FB-\U0001F3FF])?(?:‍[\U0001F000-\U0001FAFF☀-➿♀♂]️?)*')
SLIM = ((0, 4351), (8192, 8205), (8208, 8223), (8242, 8247))    # X counts these as 1 (Greek is in here), the rest as 2

def has_url(text):
    return bool(URL_RE.search(text or ''))

def x_length(text):
    """Length the way X counts it: every link is 23, an emoji is 2, Latin and Greek are 1."""
    text = unicodedata.normalize('NFC', text or '')
    count = 0
    def link(m):
        nonlocal count
        tail = re.search(r'[.,!?;:)]+$', m.group())
        count += 23
        return tail.group() if tail else ''
    text = URL_RE.sub(link, text)
    def emoji(m):
        nonlocal count
        count += 2
        return ''
    text = EMOJI_RE.sub(emoji, text)
    for ch in text:
        c = ord(ch)
        count += 1 if any(a <= c <= b for a, b in SLIM) else 2
    return count

# ---------------------------------------------------------------- pictures

def _load(path):
    im = ImageOps.exif_transpose(Image.open(path))
    icc = im.info.get('icc_profile')
    if icc:                                       # Instagram wants sRGB
        try:
            import io
            im = ImageCms.profileToProfile(im, ImageCms.ImageCmsProfile(io.BytesIO(icc)), ImageCms.createProfile('sRGB'), outputMode='RGB')
        except (OSError, ValueError, ImageCms.PyCMSError):
            pass
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA')
        back = Image.new('RGB', im.size, (0, 0, 0))
        back.paste(im, mask=im.getchannel('A'))
        return back
    return im.convert('RGB')

def _jpeg(im, dest, limit):
    for q in (92, 88, 82, 75, 65, 55):
        im.save(dest, 'JPEG', quality=q, optimize=True, subsampling=0 if q >= 88 else 2)
        if os.path.getsize(dest) <= limit: return dest
    raise PostError('This picture is too big to get under the size limit.')

def fit_ratio(im, lo, hi, mode):
    """Brings a picture inside the lo..hi width/height range: pad = blurred copy behind it, crop = trim from the centre."""
    w, h = im.size
    r = w / h
    if lo <= r <= hi or abs(r - min(max(r, lo), hi)) < 0.004: return im
    t = min(max(r, lo), hi)
    if mode == 'crop':
        cw, ch = (round(h * t), h) if r > t else (w, round(w / t))
        x, y = (w - cw) // 2, (h - ch) // 2
        return im.crop((x, y, x + cw, y + ch))
    cw, ch = (w, round(w / t)) if r > t else (round(h * t), h)
    back = ImageOps.fit(im, (cw, ch)).filter(ImageFilter.GaussianBlur(max(cw, ch) / 24))
    back = Image.eval(back, lambda v: int(v * 0.45))
    back.paste(im, ((cw - w) // 2, (ch - h) // 2))
    return back

def feed_ratio(path):
    w, h = Image.open(path).size
    return min(max(w / h, 0.8), 1.91)

def for_instagram(path, tmp, lo, hi, fit):
    """A JPEG inside Instagram's rules: 320-1440 wide, 8 MB, sRGB, lo..hi ratio."""
    im = fit_ratio(_load(path), lo, hi, fit)
    if im.width > 1440: im = im.resize((1440, round(im.height * 1440 / im.width)), Image.LANCZOS)
    if im.width < 320: im = im.resize((320, round(im.height * 320 / im.width)), Image.LANCZOS)
    return _jpeg(im, os.path.join(tmp, uuid.uuid4().hex + '.jpg'), 8 * MB)

def under(path, tmp, limit, kinds):
    """The original when it already fits, otherwise a JPEG that does."""
    if os.path.getsize(path) <= limit and os.path.splitext(path)[1].lower() in kinds: return path
    return _jpeg(_load(path), os.path.join(tmp, uuid.uuid4().hex + '.jpg'), limit)

# ---------------------------------------------------------------- X

def _pct(s):
    return urllib.parse.quote(str(s), safe='~-._')

def oauth1_sign(method, url, params, api_secret, access_secret):
    line = '&'.join(f'{k}={v}' for k, v in sorted((_pct(k), _pct(v)) for k, v in params.items()))
    base = '&'.join((method.upper(), _pct(url), _pct(line)))
    key = f'{_pct(api_secret)}&{_pct(access_secret)}'
    return base64.b64encode(hmac.new(key.encode(), base.encode(), hashlib.sha1).digest()).decode()

def oauth1_header(method, url, keys, params=None, nonce=None, stamp=None):
    """params = the query string and any form fields. JSON and multipart bodies are not signed."""
    o = {'oauth_consumer_key': keys['api_key'], 'oauth_nonce': nonce or uuid.uuid4().hex, 'oauth_signature_method': 'HMAC-SHA1',
         'oauth_timestamp': str(stamp or int(time.time())), 'oauth_token': keys['access_token'], 'oauth_version': '1.0'}
    o['oauth_signature'] = oauth1_sign(method, url, {**(params or {}), **o}, keys['api_secret'], keys['access_secret'])
    return 'OAuth ' + ', '.join(f'{_pct(k)}="{_pct(v)}"' for k, v in sorted(o.items()))

def x_problem(status, d):
    errs = d.get('errors') or [{}]
    msg = d.get('detail') or d.get('title') or errs[0].get('message') or errs[0].get('detail') or d.get('raw') or f'HTTP {status}'
    low = msg.lower()
    if 'duplicate' in low: return 'X refused this because it matches one of your recent posts. Change the text a little.'
    if status == 401: return 'X did not accept the keys. Generate them again and reconnect on the Accounts page.'
    if status == 402 or 'credit' in low: return 'Your X API credit has run out. Top it up in the X developer console and try again.'
    if status == 403 and ('oauth' in low or 'permission' in low or 'forbidden' in low):
        return f'X says this app cannot post ({msg}). Set the app to Read and Write, then generate a new Access Token.'
    if status == 429: return 'X says that is too many requests for now. Wait a while and try again.'
    return f'X said: {msg}'

def x_call(method, path, keys, query=None, body=None, fields=None, files=None, final=False):
    url = X_API + path
    head = {'Authorization': oauth1_header(method, url, keys, query)}
    data = None
    if files or fields:
        data, head['Content-Type'] = multipart(fields or {}, files or {})
    elif body is not None:
        data = json.dumps(body).encode('utf8')
        head['Content-Type'] = 'application/json'
    status, d = http(method, url + ('?' + urllib.parse.urlencode(query) if query else ''), head, data, final=final)
    if status >= 400: raise PostError(x_problem(status, d))
    return d

def x_me(keys):
    d = x_call('GET', '/2/users/me', keys)['data']
    return {'id': d['id'], 'username': d['username'], 'name': d.get('name', d['username'])}

def x_picture(path, keys):
    with open(path, 'rb') as f: data = f.read()
    mime = 'image/png' if path.lower().endswith('.png') else 'image/webp' if path.lower().endswith('.webp') else 'image/jpeg'
    d = x_call('POST', '/2/media/upload', keys, fields={'media_category': 'tweet_image'}, files={'media': (os.path.basename(path), data, mime)})
    return d['data']['id']

def x_video(path, keys, say):
    size = os.path.getsize(path)
    mime = 'video/quicktime' if path.lower().endswith('.mov') else 'video/mp4'
    mid = x_call('POST', '/2/media/upload/initialize', keys, body={'media_type': mime, 'total_bytes': size, 'media_category': 'tweet_video'})['data']['id']
    with open(path, 'rb') as f:
        for i in range(size // X_CHUNK + (1 if size % X_CHUNK else 0)):
            say(f'Uploading video ({min(100, (i * X_CHUNK * 100) // max(size, 1))}%)')
            x_call('POST', f'/2/media/upload/{mid}/append', keys, fields={'segment_index': i}, files={'media': ('chunk', f.read(X_CHUNK), 'application/octet-stream')})
    info = x_call('POST', f'/2/media/upload/{mid}/finalize', keys).get('data', {}).get('processing_info')
    end = time.time() + 600
    while info and info.get('state') not in ('succeeded', None):
        if info['state'] == 'failed': raise PostError('X could not process this video: ' + str(info.get('error', {}).get('message', 'no reason given')))
        if time.time() > end: raise PostError('X took more than ten minutes to process the video.')
        say('X is processing the video')
        time.sleep(max(1, info.get('check_after_secs', 2)))
        info = x_call('GET', '/2/media/upload', keys, query={'command': 'STATUS', 'media_id': mid}).get('data', {}).get('processing_info')
    return mid

def post_x(job, creds, say):
    keys, tmp = creds['x'], job['tmp']
    ids = []
    for i, m in enumerate(job['media']):
        if m['kind'] == 'video':
            ids.append(x_video(m['path'], keys, say))
        else:
            say(f'Uploading picture {i + 1} of {len(job["media"])}')
            ids.append(x_picture(under(m['path'], tmp, 5 * MB, ('.jpg', '.jpeg', '.png', '.webp')), keys))
    say('Posting')
    body = {}
    if job['text']: body['text'] = job['text']
    if ids: body['media'] = {'media_ids': ids}
    pid = x_call('POST', '/2/tweets', keys, body=body, final=True)['data']['id']
    return {'id': pid, 'url': f'https://x.com/{keys.get("username") or "i"}/status/{pid}'}

# ---------------------------------------------------------------- Facebook

HINTS = {190: 'The Facebook sign-in has expired or was revoked. Reconnect on the Accounts page.',
         10: 'The app does not have the permission it needs. Check the permissions in step 3 on the Accounts page.',
         200: 'The app does not have the permission it needs. Check the permissions in step 3 on the Accounts page.',
         4: 'That is too many requests for now. Wait a while and try again.', 17: 'That is too many requests for now. Wait a while and try again.',
         32: 'That is too many requests for now. Wait a while and try again.', 368: 'Facebook has temporarily blocked this Page from posting.',
         9004: 'Instagram could not fetch the picture from Facebook.', 36003: 'Instagram did not accept the picture ratio.'}

def meta_problem(status, d, who):
    e = d.get('error') or {}
    msg = e.get('error_user_msg') or e.get('message') or d.get('raw') or f'HTTP {status}'
    hint = HINTS.get(e.get('code'))
    return f'{hint} ({who} said: {msg})' if hint else f'{who} said: {msg}'

def graph(method, path, token, fields=None, files=None, base=None, final=False, who='Facebook', query=None):
    url = (base or GRAPH) + path + ('?' + urllib.parse.urlencode(query) if query else '')
    head = {'Authorization': f'Bearer {token}'} if token else {}
    data = None
    if files:
        data, head['Content-Type'] = multipart(fields or {}, files)
    elif fields is not None:
        data = urllib.parse.urlencode(fields).encode('utf8')
        head['Content-Type'] = 'application/x-www-form-urlencoded'
    status, d = http(method, url, head, data, final=final)
    if status >= 400 or 'error' in d: raise PostError(meta_problem(status, d, who))
    return d

def meta_long_token(app_id, app_secret, short):
    d = graph('GET', '/oauth/access_token', None, query={'grant_type': 'fb_exchange_token', 'client_id': app_id, 'client_secret': app_secret, 'fb_exchange_token': short})
    return d['access_token']

def meta_pages(user_token):
    d = graph('GET', '/me/accounts', user_token, query={'fields': 'id,name,access_token,instagram_business_account{id,username}', 'limit': 100})
    return d.get('data', [])

def meta_expiry(token, app_id, app_secret):
    """Unix time the token runs out, or 0 for never. None when Facebook will not say."""
    try:
        d = graph('GET', '/debug_token', None, query={'input_token': token, 'access_token': f'{app_id}|{app_secret}'})
        return d.get('data', {}).get('expires_at')
    except PostError:
        return None

def meta_health(c):
    out = {'page': graph('GET', f'/{c["page_id"]}', c['page_token'], query={'fields': 'name'}).get('name')}
    if c.get('ig_id'):
        rows = graph('GET', f'/{c["ig_id"]}/content_publishing_limit', c['page_token'], who='Instagram', query={'fields': 'quota_usage,config'}).get('data') or [{}]
        out['used'], out['quota'] = rows[0].get('quota_usage'), rows[0].get('config', {}).get('quota_total')
    return out

def _photo(c, path, fields, final=False):
    with open(path, 'rb') as f: data = f.read()
    mime = 'image/png' if path.lower().endswith('.png') else 'image/jpeg'
    return graph('POST', f'/{c["page_id"]}/photos', c['page_token'], fields=fields, files={'source': (os.path.basename(path), data, mime)}, final=final)

def post_facebook(job, creds, say):
    c, tmp, text, media = creds['meta'], job['tmp'], job['text'], job['media']
    page = c['page_id']
    if media and media[0]['kind'] == 'video':
        say('Uploading video')
        with open(media[0]['path'], 'rb') as f: data = f.read()
        d = graph('POST', f'/{page}/videos', c['page_token'], fields={'description': text}, files={'source': (os.path.basename(media[0]['path']), data, 'video/mp4')}, base=GRAPH_VIDEO, final=True)
        return {'id': d['id'], 'url': f'https://www.facebook.com/{page}/videos/{d["id"]}'}
    files = [under(m['path'], tmp, 10 * MB, ('.jpg', '.jpeg', '.png')) for m in media]
    if len(files) == 1:
        say('Uploading picture')
        d = _photo(c, files[0], {'caption': text}, final=True)
        return {'id': d.get('post_id') or d['id'], 'url': f'https://www.facebook.com/{d.get("post_id") or d["id"]}'}
    fields = {'message': text}
    for i, f in enumerate(files):
        say(f'Uploading picture {i + 1} of {len(files)}')
        fields[f'attached_media[{i}]'] = json.dumps({'media_fbid': _photo(c, f, {'published': 'false'})['id']})
    if not files:
        m = URL_RE.search(text)
        if m: fields['link'] = m.group() if m.group().lower().startswith('http') else 'https://' + m.group()
    say('Posting')
    d = graph('POST', f'/{page}/feed', c['page_token'], fields=fields, final=True)
    return {'id': d['id'], 'url': f'https://www.facebook.com/{d["id"]}'}

# ---------------------------------------------------------------- Instagram

def _hosted(c, path):
    """Puts the picture on the Page, unpublished, and returns (photo id, public address)."""
    pid = _photo(c, path, {'published': 'false'})['id']
    images = graph('GET', f'/{pid}', c['page_token'], query={'fields': 'images'}).get('images') or []
    if not images: raise PostError('Facebook did not give an address for the picture, so Instagram cannot fetch it.')
    return pid, max(images, key=lambda x: x.get('width', 0))['source']

WAITS = (2, 3, 5, 10, 15, 30, 30, 30, 30, 30, 30, 30, 30, 30)      # the docs ask for no more than five minutes of checks

def _ready(c, cid, say):
    for wait in WAITS:
        code = graph('GET', f'/{cid}', c['page_token'], who='Instagram', query={'fields': 'status_code'}).get('status_code')
        if code in ('FINISHED', 'PUBLISHED'): return
        if code in ('ERROR', 'EXPIRED'):
            d = graph('GET', f'/{cid}', c['page_token'], who='Instagram', query={'fields': 'status,status_code'})
            raise PostError('Instagram could not process this media: ' + str(d.get('status') or code))
        say('Instagram is processing the media')
        time.sleep(wait)
    raise PostError('Instagram was still processing after five minutes. Nothing was published.')

def _container(c, fields):
    return graph('POST', f'/{c["ig_id"]}/media', c['page_token'], fields=fields, who='Instagram')

def _reel(c, m, fields, say):
    say('Sending video to Instagram')
    d = _container(c, {**fields, 'upload_type': 'resumable'})
    size = os.path.getsize(m['path'])
    with open(m['path'], 'rb') as f:
        status, r = http('POST', d['uri'], {'Authorization': f'OAuth {c["page_token"]}', 'offset': '0', 'file_size': str(size), 'Content-Length': str(size)}, f, timeout=1800)
    if status >= 400 or not r.get('success'): raise PostError(meta_problem(status, r, 'Instagram'))
    return d['id']

def post_instagram(job, creds, say):
    c, tmp, media, fmt, fit = creds['meta'], job['tmp'], job['media'], job['fmt'], job['fit']
    caption = job['text']
    hosted = []
    def host(path):
        pid, url = _hosted(c, path)
        hosted.append(pid)
        return url
    try:
        if media[0]['kind'] == 'video':
            fields = {'media_type': 'STORIES'} if fmt == 'story' else {'media_type': 'REELS', 'caption': caption, 'share_to_feed': 'true'}
            cid = _reel(c, media[0], fields, say)
        elif fmt == 'story':
            say('Preparing picture')
            url = host(for_instagram(media[0]['path'], tmp, 9 / 16, 9 / 16, fit))
            cid = _container(c, {'media_type': 'STORIES', 'image_url': url})['id']
        elif len(media) == 1:
            say('Preparing picture')
            url = host(for_instagram(media[0]['path'], tmp, 0.8, 1.91, fit))
            cid = _container(c, {'image_url': url, 'caption': caption})['id']
        else:
            r = feed_ratio(media[0]['path'])                  # Instagram crops the rest to the first one's ratio
            kids = []
            for i, m in enumerate(media):
                say(f'Preparing picture {i + 1} of {len(media)}')
                url = host(for_instagram(m['path'], tmp, r, r, fit))
                kids.append(_container(c, {'image_url': url, 'is_carousel_item': 'true'})['id'])
            for k in kids: _ready(c, k, say)
            cid = _container(c, {'media_type': 'CAROUSEL', 'children': ','.join(kids), 'caption': caption})['id']
        _ready(c, cid, say)
        say('Posting')
        mid = graph('POST', f'/{c["ig_id"]}/media_publish', c['page_token'], fields={'creation_id': cid}, final=True, who='Instagram')['id']
    finally:
        for pid in hosted:
            try: graph('DELETE', f'/{pid}', c['page_token'])
            except PostError: pass
    try: url = graph('GET', f'/{mid}', c['page_token'], who='Instagram', query={'fields': 'permalink'}).get('permalink', '')
    except PostError: url = ''
    return {'id': mid, 'url': url}

def rehearse(job, target, say):
    """Test mode: does the picture work for real, then stops short of the network."""
    tmp, media = job['tmp'], job['media']
    pics = [m for m in media if m['kind'] == 'image']
    for i, m in enumerate(pics):
        say(f'Preparing picture {i + 1} of {len(pics)}')
        if target == 'instagram':
            r = 9 / 16 if job['fmt'] == 'story' else feed_ratio(pics[0]['path']) if len(pics) > 1 else None
            for_instagram(m['path'], tmp, r or 0.8, r or 1.91, job['fit'])
        elif target == 'x': under(m['path'], tmp, 5 * MB, ('.jpg', '.jpeg', '.png', '.webp'))
        else: under(m['path'], tmp, 10 * MB, ('.jpg', '.jpeg', '.png'))
        time.sleep(0.15)
    say('Posting')
    time.sleep(0.4)
    return {'id': 'test', 'url': ''}
