"""Powerslide Social Hub: write one post here and it goes out to X, Facebook and Instagram.

Run "Social Hub.bat" (or: python hub.py). It opens in your browser at http://127.0.0.1:8776.
Posts are saved as data/posts/<id>.json, media in data/media, and your keys in data/secrets.bin, which only
your Windows account can read. Nothing leaves this PC until you press Post, or a scheduled time comes up.
Scheduled posts only go out while this window is open."""
import argparse, ctypes, datetime, hashlib, json, mimetypes, os, re, shutil, tempfile, threading, time, uuid, webbrowser
import urllib.parse
from ctypes import wintypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from PIL import Image, ImageOps
import platforms as P
from platforms import PostError

HERE = os.path.dirname(os.path.abspath(__file__))
UI = os.path.join(HERE, 'ui')
PORT = 8776
TARGETS = ('x', 'facebook', 'instagram')
LABEL = {'x': 'X', 'facebook': 'Facebook', 'instagram': 'Instagram'}
LATE = 15 * 60                 # a scheduled post this late is held back for you instead of going out
MAX_UPLOAD = 1024 * 1024 * 1024
IMAGES = ('.jpg', '.jpeg', '.png', '.webp')
VIDEOS = ('.mp4', '.mov')
DEFAULTS = {'test_mode': True, 'tray_dir': os.path.join(os.path.expanduser('~'), 'Pictures', 'Powerslide Graphics'),
            'snippets': ['Link in bio!', "Let's have a look!", '#WRC #Rally']}
LOCK = threading.RLock()
PENDING = {}                   # Facebook Pages waiting for you to pick one
mimetypes.add_type('image/webp', '.webp')

class Paths:
    def __init__(self, root):
        self.root, self.posts, self.media, self.thumbs, self.work = root, os.path.join(root, 'posts'), os.path.join(root, 'media'), os.path.join(root, 'thumbs'), os.path.join(root, 'work')
        self.settings, self.secrets = os.path.join(root, 'settings.json'), os.path.join(root, 'secrets.bin')
        for d in (self.posts, self.media, self.thumbs, self.work): os.makedirs(d, exist_ok=True)
D = None

def write_json(path, data):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf8') as f: json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)

# ---------------------------------------------------------------- keys

class Blob(ctypes.Structure):
    _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_char))]

def dpapi(fn, raw):
    buf = ctypes.create_string_buffer(raw, len(raw))
    src, out = Blob(len(raw), buf), Blob()
    if not fn(ctypes.byref(src), None, None, None, None, 0, ctypes.byref(out)): raise OSError('Windows could not protect the keys.')
    try: return ctypes.string_at(out.data, out.size)
    finally: ctypes.windll.kernel32.LocalFree(out.data)

def read_secrets():
    if not os.path.exists(D.secrets): return {}
    try:
        with open(D.secrets, 'rb') as f: return json.loads(dpapi(ctypes.windll.crypt32.CryptUnprotectData, f.read()))
    except (OSError, ValueError):
        return {}

def write_secrets(s):
    blob = dpapi(ctypes.windll.crypt32.CryptProtectData, json.dumps(s).encode('utf8'))
    tmp = D.secrets + '.tmp'
    with open(tmp, 'wb') as f: f.write(blob)
    os.replace(tmp, D.secrets)

def accounts():
    s = read_secrets()
    x, m = s.get('x'), s.get('meta')
    return {'x': {'connected': bool(x), 'name': '@' + x['username'] if x else '', 'title': x.get('name', '') if x else ''},
            'facebook': {'connected': bool(m), 'name': m.get('page_name', '') if m else '', 'expires': m.get('expires') if m else None},
            'instagram': {'connected': bool(m and m.get('ig_id')), 'name': '@' + m['ig_name'] if m and m.get('ig_name') else '', 'page': bool(m)}}

# ---------------------------------------------------------------- settings and posts

def settings():
    if os.path.exists(D.settings):
        with open(D.settings, encoding='utf8') as f: return {**DEFAULTS, **json.load(f)}
    return dict(DEFAULTS)

def post_file(pid):
    if not re.fullmatch(r'[\w-]{1,80}', pid or ''): raise ValueError('bad post id')
    return os.path.join(D.posts, pid + '.json')

def load(pid):
    path = post_file(pid)
    with LOCK:                     # Windows will not replace a file while another thread is reading it
        if not os.path.exists(path): raise LookupError('That post is gone.')
        with open(path, encoding='utf8') as f: return json.load(f)

def store(p):
    p['updated'] = int(time.time())
    with LOCK: write_json(post_file(p['id']), p)
    return p

def all_posts():
    out = []
    with LOCK:
        for f in os.listdir(D.posts):
            if f.endswith('.json'):
                try:
                    with open(os.path.join(D.posts, f), encoding='utf8') as h: out.append(json.load(h))
                except ValueError: pass
    out.sort(key=lambda x: x.get('updated', 0), reverse=True)
    return out

def clean(x):
    """Keeps only what the composer is allowed to set."""
    per = {}
    for t in TARGETS:
        o = (x.get('per') or {}).get(t) or {}
        per[t] = {'on': bool(o.get('on')), 'text': o.get('text') if isinstance(o.get('text'), str) else None}
    ig = (x.get('per') or {}).get('instagram') or {}
    per['instagram']['fmt'] = ig.get('fmt') if ig.get('fmt') in ('feed', 'story') else 'feed'
    per['instagram']['fit'] = ig.get('fit') if ig.get('fit') in ('pad', 'crop') else 'pad'
    media = []
    for m in x.get('media') or []:
        if not re.fullmatch(r'[0-9a-f]{32}\.\w{3,4}', str(m.get('id', ''))) or not os.path.exists(os.path.join(D.media, m['id'])): continue
        media.append({k: m.get(k) for k in ('id', 'name', 'kind', 'w', 'h', 'size', 'duration')})
    when = x.get('when')
    return {'text': str(x.get('text') or ''), 'per': per, 'media': media, 'when': int(when) if when else None}

def text_for(p, t):
    own = p['per'][t].get('text')
    return (p['text'] if own is None else own).strip()

def check(p):
    """What each platform will make of this post. Level 'stop' keeps it from posting."""
    acc, test = accounts(), settings()['test_mode']
    media = p['media']
    pics = [m for m in media if m['kind'] == 'image']
    vids = [m for m in media if m['kind'] == 'video']
    both = bool(pics and vids)
    out = {}
    for t in TARGETS:
        if not p['per'][t]['on']: continue
        text, notes = text_for(p, t), []
        stop = lambda m: notes.append({'level': 'stop', 'text': m})
        warn = lambda m: notes.append({'level': 'warn', 'text': m})
        if not acc[t]['connected'] and not test:
            stop(f'{LABEL[t]} is not connected yet. You can do that on the Accounts page.')
        if both: stop('Use pictures or one video, not both.')
        if len(vids) > 1: stop('Only one video can go in a post.')
        row = {'count': len(text), 'limit': None, 'notes': notes}
        if t == 'x':
            row['count'], row['limit'] = P.x_length(text), 280
            row['cost'] = 0.2 if P.has_url(text) else 0.015
            if not text and not media: stop('Write something or add a picture.')
            if row['count'] > 280: stop(f'This is {row["count"] - 280} over the 280 limit. Give X its own shorter text.')
            if len(pics) > 4: stop('X takes up to 4 pictures in a post.')
            if vids and (vids[0].get('duration') or 0) > 1200: warn('X only takes videos over 20 minutes from Premium accounts.')
            if P.has_url(text): warn('This text has a link, so X charges $0.20 for it instead of $0.015.')
        elif t == 'facebook':
            row['limit'] = 63206
            if not text and not media: stop('Write something or add a picture.')
            if len(text) > 63206: stop('This is too long for Facebook.')
            if len(pics) > 20: stop('Keep it to 20 pictures.')
        else:
            row['limit'] = 2200
            fmt = p['per'][t]['fmt']
            tags, ats = len(re.findall(r'(?<!\w)#\w+', text)), len(re.findall(r'(?<!\w)@\w+', text))
            row['tags'] = tags
            if not media: stop('Instagram needs a picture or a video.')
            if len(text) > 2200: stop(f'This is {len(text) - 2200} over the 2,200 limit.')
            if tags > 30: stop(f'That is {tags} hashtags and Instagram takes 30.')
            if ats > 20: stop(f'That is {ats} @ mentions and Instagram takes 20.')
            if len(pics) > 20: stop('Instagram takes up to 20 pictures in a carousel.')
            if fmt == 'story':
                if len(media) > 1: stop('A Story takes one picture or video.')
                if text: warn('Stories have no caption, so this text will not show on Instagram.')
            if vids:
                v, size, secs = vids[0], vids[0].get('size') or 0, vids[0].get('duration') or 0
                if fmt == 'story':
                    if secs > 60: stop('A Story video can be 60 seconds at most.')
                    if size > 100 * P.MB: stop('A Story video can be 100 MB at most.')
                else:
                    if secs and not 3 <= secs <= 900: stop('A Reel has to be between 3 seconds and 15 minutes.')
                    if size > 300 * P.MB: stop('A Reel can be 300 MB at most.')
        out[t] = row
    if not any(p['per'][t]['on'] for t in TARGETS): out['none'] = {'notes': [{'level': 'stop', 'text': 'Pick at least one platform.'}]}
    return out

def blockers(p):
    return [f'{LABEL.get(t, "Post")}: {n["text"]}' for t, r in check(p).items() for n in r['notes'] if n['level'] == 'stop']

# ---------------------------------------------------------------- posting

def finish(p):
    states = [r.get('state') for r in p['results'].values()]
    p['status'] = 'done' if states and all(s == 'posted' for s in states) else 'failed' if not any(s in ('posted', 'unsure') for s in states) else 'partial'
    p['finished'] = int(time.time())

def begin(pid, only=None, expect=None):
    with LOCK:
        p = load(pid)
        if p['status'] == 'posting': raise ValueError('This post is already going out.')
        if expect and p['status'] != expect: return p      # someone pressed Post now just before its time came
        ts = only or [t for t in TARGETS if p['per'][t]['on']]
        if p['status'] not in ('scheduled',): p['test'] = settings()['test_mode']
        p['results'] = {k: v for k, v in (p.get('results') or {}).items() if k not in ts}
        for t in ts: p['results'][t] = {'state': 'working', 'step': 'Getting ready'}
        p['status'] = 'posting'
        store(p)
    threading.Thread(target=run, args=(pid, ts), daemon=True).start()
    return p

def run(pid, ts):
    workers = [threading.Thread(target=run_one, args=(pid, t)) for t in ts]
    for w in workers: w.start()
    for w in workers: w.join()
    with LOCK:
        p = load(pid)
        finish(p)
        store(p)

def update(pid, t, **kw):
    with LOCK:
        p = load(pid)
        p['results'][t].update(kw)
        store(p)

def run_one(pid, t):
    tmp = tempfile.mkdtemp(dir=D.work)
    try:
        with LOCK: p = load(pid)
        job = {'text': text_for(p, t), 'tmp': tmp, 'fmt': p['per'][t].get('fmt', 'feed'), 'fit': p['per'][t].get('fit', 'pad'),
               'media': [{**m, 'path': os.path.join(D.media, m['id'])} for m in p['media']]}
        say = lambda s: update(pid, t, step=s)
        if p.get('test'):
            out = P.rehearse(job, t, say)
        else:
            problems = [n['text'] for n in check(p).get(t, {}).get('notes', []) if n['level'] == 'stop']
            if problems: raise PostError(problems[0])
            out = {'x': P.post_x, 'facebook': P.post_facebook, 'instagram': P.post_instagram}[t](job, read_secrets(), say)
        update(pid, t, state='posted', step='', at=int(time.time()), **out)
    except PostError as e:
        update(pid, t, state='unsure' if e.unsure else 'failed', step='', error=str(e))
    except Exception as e:                 # a broken file must not leave the post stuck on "posting"
        update(pid, t, state='failed', step='', error=f'{type(e).__name__}: {e}')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def scheduler():
    while True:
        now = time.time()
        for p in all_posts():
            if p.get('status') == 'scheduled' and p.get('when') and p['when'] <= now:
                try:
                    if now - p['when'] > LATE:
                        with LOCK:
                            p = load(p['id'])
                            p['status'] = 'missed'
                            store(p)
                    else:
                        begin(p['id'], expect='scheduled')
                except (ValueError, LookupError):
                    pass
        time.sleep(5)

def recover():
    """If the hub closed halfway through a post, say so instead of leaving it spinning."""
    for p in all_posts():
        if p.get('status') == 'posting':
            for r in p['results'].values():
                if r.get('state') == 'working':
                    r.update(state='unsure', step='', error='The hub closed while this was posting, so it may or may not have gone out. Have a look at the page.')
            finish(p)
            store(p)

def x_spend():
    month = datetime.date.today().replace(day=1)
    since = datetime.datetime(month.year, month.month, 1).timestamp()
    total, count = 0, 0
    for p in all_posts():
        r = (p.get('results') or {}).get('x') or {}
        if r.get('state') == 'posted' and not p.get('test') and r.get('at', 0) >= since:
            count += 1
            total += 0.2 if P.has_url(text_for(p, 'x')) else 0.015
    return {'count': count, 'total': round(total, 3)}

# ---------------------------------------------------------------- media

def media_info(path, name, mid):
    ext = os.path.splitext(path)[1].lower()
    info = {'id': mid, 'name': name, 'kind': 'video' if ext in VIDEOS else 'image', 'size': os.path.getsize(path), 'w': None, 'h': None, 'duration': None}
    if info['kind'] == 'image':
        try:
            with Image.open(path) as im:
                im.verify()
            with Image.open(path) as im:
                info['w'], info['h'] = ImageOps.exif_transpose(im).size
        except Exception:
            os.remove(path)
            raise ValueError('That file is not a picture this hub can read.')
    return info

def new_media_path(name):
    ext = os.path.splitext(name)[1].lower()
    if ext not in IMAGES + VIDEOS: raise ValueError('Use a JPG, PNG, WebP, MP4 or MOV file.')
    mid = uuid.uuid4().hex + ext
    return mid, os.path.join(D.media, mid)

def thumb(src, key):
    out = os.path.join(D.thumbs, key + '.jpg')
    if not os.path.exists(out):
        with Image.open(src) as im:
            im = ImageOps.exif_transpose(im).convert('RGB')
            im.thumbnail((320, 320))
            im.save(out, 'JPEG', quality=82)
    return out

def tray():
    d = settings()['tray_dir']
    if not os.path.isdir(d): return {'dir': d, 'found': False, 'files': []}
    files = [e for e in os.scandir(d) if e.is_file() and os.path.splitext(e.name)[1].lower() in IMAGES]
    files.sort(key=lambda e: e.stat().st_mtime, reverse=True)
    return {'dir': d, 'found': True, 'files': [{'name': e.name, 'time': int(e.stat().st_mtime)} for e in files[:30]]}

def tray_path(name):
    name = os.path.basename(name or '')
    path = os.path.join(settings()['tray_dir'], name)
    if not name or not os.path.isfile(path) or os.path.splitext(name)[1].lower() not in IMAGES: raise LookupError('That picture is gone.')
    return path

def forget_media(p):
    used = {m['id'] for o in all_posts() if o['id'] != p['id'] for m in o.get('media', [])}
    for m in p.get('media', []):
        if m['id'] not in used:
            try: os.remove(os.path.join(D.media, m['id']))
            except OSError: pass

# ---------------------------------------------------------------- web server

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def send(self, data, code=200, kind='application/json; charset=utf-8'):
        body = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode('utf8')
        self.send_response(code)
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def file(self, path):
        if not os.path.isfile(path): return self.send({'error': 'Not found'}, 404)
        with open(path, 'rb') as f: self.send(f.read(), kind=mimetypes.guess_type(path)[0] or 'application/octet-stream')

    def safe(self):
        """Only this hub's own page may use it: no other website can post through it from your browser."""
        host = self.headers.get('Host', '')
        ok = {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}
        origin = self.headers.get('Origin')
        if host not in ok or (origin and origin not in {'http://' + h for h in ok}) or self.headers.get('Sec-Fetch-Site') == 'cross-site':
            self.send({'error': 'Blocked'}, 403)
            return False
        return True

    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        return json.loads(self.rfile.read(n) or b'{}') if n else {}

    def guarded(self, fn):
        if not self.safe(): return
        try: fn()
        except LookupError as e: self.send({'error': str(e.args[0] if e.args else e)}, 404)
        except (ValueError, PostError) as e: self.send({'error': str(e)}, 400)
        except OSError as e: self.send({'error': str(e)}, 500)

    def do_GET(self): self.guarded(self.get)
    def do_POST(self): self.guarded(self.post)
    def do_DELETE(self): self.guarded(self.delete)

    def get(self):
        u = urllib.parse.urlparse(self.path)
        path, q = u.path, urllib.parse.parse_qs(u.query)
        if path == '/': return self.file(os.path.join(UI, 'index.html'))
        if path.startswith('/ui/'):
            return self.file(os.path.join(UI, os.path.basename(path)))
        if path.startswith('/media/'):
            return self.file(os.path.join(D.media, os.path.basename(path)))
        if path.startswith('/thumb/'):
            mid = os.path.basename(path)
            return self.file(thumb(os.path.join(D.media, mid), mid.split('.')[0]))
        if path == '/tray-thumb':
            src = tray_path(q.get('name', [''])[0])
            return self.file(thumb(src, 't' + hashlib.md5(f'{src}{os.path.getmtime(src)}'.encode('utf8')).hexdigest()))
        if path == '/api/state':
            return self.send({'accounts': accounts(), 'settings': settings(), 'spend': x_spend(), 'posts': all_posts(), 'now': int(time.time())})
        if path == '/api/tray': return self.send(tray())
        if path.startswith('/api/posts/'): return self.send(load(path.split('/')[3]))
        self.send({'error': 'Not found'}, 404)

    def post(self):
        path = urllib.parse.urlparse(self.path).path
        if path == '/api/media': return self.upload()
        x = self.body()
        if path == '/api/check':
            return self.send(check(clean(x)))
        if path == '/api/posts':                                   # save as draft or scheduled
            with LOCK:
                p = self.saved(x)
                sched = x.get('schedule') and p['when']
                if sched:
                    if p['when'] <= time.time(): raise ValueError('Pick a time in the future.')
                    stops = blockers(p)
                    if stops: raise ValueError(stops[0])
                    p['test'] = settings()['test_mode']
                p['status'] = 'scheduled' if sched else 'draft'
                if not sched: p['when'] = None
                return self.send(store(p))
        if path == '/api/publish':
            with LOCK:
                p = self.saved(x)
                stops = blockers(p)
                if stops: raise ValueError(stops[0])
                p['status'] = 'draft'
                store(p)
                return self.send(begin(p['id']))
        m = re.fullmatch(r'/api/posts/([\w-]+)/(retry|now|unschedule)', path)
        if m:
            pid, act = m.groups()
            p = load(pid)
            if act == 'unschedule':
                with LOCK:
                    p = load(pid)
                    if p['status'] != 'scheduled': raise ValueError('This post is not scheduled any more.')
                    p.update(status='draft', when=None)
                    return self.send(store(p))
            if act == 'now':
                with LOCK:
                    p = load(pid)
                    if p['status'] not in ('draft', 'scheduled', 'missed'): raise ValueError('This post has already gone out, or is going out now.')
                    stops = blockers(p)
                    if stops: raise ValueError(stops[0])
                    p['status'] = 'draft'
                    store(p)
                    return self.send(begin(pid))
            wanted = ('failed', 'unsure') if x.get('unsure') else ('failed',)
            ts = [t for t, r in (p.get('results') or {}).items() if r.get('state') in wanted]
            if not ts: raise ValueError('There is nothing to retry.')
            return self.send(begin(pid, ts))
        if path == '/api/settings':
            with LOCK:
                s = settings()
                if 'test_mode' in x: s['test_mode'] = bool(x['test_mode'])
                if 'tray_dir' in x: s['tray_dir'] = str(x['tray_dir']).strip()
                if 'snippets' in x: s['snippets'] = [str(i).strip() for i in x['snippets'] if str(i).strip()][:20]
                write_json(D.settings, s)
            return self.send(s)
        if path == '/api/tray/add':
            src = tray_path(x.get('name'))
            mid, dest = new_media_path(src)
            shutil.copyfile(src, dest)
            return self.send(media_info(dest, os.path.basename(src), mid))
        if path == '/api/connect/x':
            keys = {k: str(x.get(k) or '').strip() for k in ('api_key', 'api_secret', 'access_token', 'access_secret')}
            if not all(keys.values()): raise ValueError('All four keys are needed.')
            me = P.x_me(keys)
            with LOCK:
                s = read_secrets()
                s['x'] = {**keys, **me}
                write_secrets(s)
            return self.send(accounts())
        if path == '/api/connect/meta':
            app_id, secret, short = (str(x.get(k) or '').strip() for k in ('app_id', 'app_secret', 'token'))
            if not (app_id and secret and short): raise ValueError('The App ID, App Secret and token are all needed.')
            long_token = P.meta_long_token(app_id, secret, short)
            pages = P.meta_pages(long_token)
            if not pages: raise ValueError('Facebook did not list any Pages. Make sure you ticked your Page when you generated the token.')
            PENDING.update(app_id=app_id, app_secret=secret, pages=pages)
            return self.send({'pages': [{'id': g['id'], 'name': g.get('name', ''), 'ig': (g.get('instagram_business_account') or {}).get('username', '')} for g in pages]})
        if path == '/api/connect/page':
            g = next((i for i in PENDING.get('pages', []) if i['id'] == x.get('id')), None)
            if not g: raise ValueError('Start again from the token step.')
            ig = g.get('instagram_business_account') or {}
            meta = {'app_id': PENDING['app_id'], 'app_secret': PENDING['app_secret'], 'page_id': g['id'], 'page_name': g.get('name', ''),
                    'page_token': g['access_token'], 'ig_id': ig.get('id', ''), 'ig_name': ig.get('username', '')}
            meta['expires'] = P.meta_expiry(g['access_token'], meta['app_id'], meta['app_secret'])
            with LOCK:
                s = read_secrets()
                s['meta'] = meta
                write_secrets(s)
            PENDING.clear()
            return self.send(accounts())
        if path == '/api/health':
            m = read_secrets().get('meta')
            if not m: raise ValueError('Facebook is not connected.')
            return self.send(P.meta_health(m))
        if path == '/api/disconnect':
            with LOCK:
                s = read_secrets()
                s.pop('x' if x.get('platform') == 'x' else 'meta', None)
                write_secrets(s)
            return self.send(accounts())
        self.send({'error': 'Not found'}, 404)

    def saved(self, x):
        pid = x.get('id')
        old = load(pid) if pid else {}
        if old.get('status') == 'posting': raise ValueError('This post is going out right now.')
        if not old.get('test') and any(r.get('state') in ('posted', 'unsure') for r in (old.get('results') or {}).values()):
            raise ValueError('This one has already gone out. Press Use again in History to make a copy.')
        return {**old, 'id': pid or uuid.uuid4().hex, 'created': old.get('created') or int(time.time()), **clean(x), 'results': {}, 'status': old.get('status', 'draft')}

    def upload(self):
        name = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get('name', ['file'])[0]
        size = int(self.headers.get('Content-Length') or 0)
        if not size or size > MAX_UPLOAD: raise ValueError('Files can be up to 1 GB.')
        mid, dest = new_media_path(name)
        left = size
        with open(dest, 'wb') as f:
            while left:
                chunk = self.rfile.read(min(left, 1024 * 1024))
                if not chunk: break
                f.write(chunk)
                left -= len(chunk)
        self.send(media_info(dest, os.path.basename(name), mid))

    def delete(self):
        m = re.fullmatch(r'/api/posts/([\w-]+)', urllib.parse.urlparse(self.path).path)
        if not m: return self.send({'error': 'Not found'}, 404)
        with LOCK:
            p = load(m.group(1))
            if p.get('status') == 'posting': raise ValueError('This post is going out right now.')
            os.remove(post_file(p['id']))
            forget_media(p)
        self.send({'ok': True})

def main():
    global D
    a = argparse.ArgumentParser()
    a.add_argument('--port', type=int, default=PORT)
    a.add_argument('--data', default=os.path.join(HERE, 'data'))
    a.add_argument('--no-browser', action='store_true')
    a.add_argument('--mock', help='send every call to tests/mock_apis.py at this address')
    o = a.parse_args()
    D = Paths(o.data)
    if o.mock: P.use_mock(o.mock.rstrip('/'))
    recover()
    threading.Thread(target=scheduler, daemon=True).start()
    srv = ThreadingHTTPServer(('127.0.0.1', o.port), Handler)
    url = f'http://127.0.0.1:{o.port}'
    print(f'Powerslide Social Hub is running at {url}\nKeep this window open: scheduled posts only go out while it is. Press Ctrl+C to stop.', flush=True)
    if not o.no_browser: threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try: srv.serve_forever()
    except KeyboardInterrupt: pass

if __name__ == '__main__':
    main()
