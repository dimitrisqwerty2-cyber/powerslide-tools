"""End-to-end test: python tests/test_hub.py
Starts the mock services and a throwaway hub with its own data folder, then goes through every posting path."""
import io, json, os, shutil, subprocess, sys, tempfile, time, urllib.error, urllib.request
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
import platforms as P
from PIL import Image

MOCK, HUB = 8798, 8797
BASE, API = f'http://127.0.0.1:{HUB}', f'http://127.0.0.1:{MOCK}'
results = []

def ok(name, cond, detail=''):
    results.append(bool(cond))
    print(('PASS ' if cond else 'FAIL ') + name + (f'  [{detail}]' if detail and not cond else ''), flush=True)

def call(path, body=None, method=None, headers=None, base=BASE):
    data = None if body is None else (body if isinstance(body, bytes) else json.dumps(body).encode())
    req = urllib.request.Request(base + path, data=data, method=method or ('POST' if data is not None else 'GET'), headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=30) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'{}')

def log(): return call('/__log', base=API)[1]
def tweets(): return [c for c in log() if c.get('x') == '/2/tweets']
def meta(path): return [c for c in log() if c.get('meta') == path]

def image(size, name, fmt='PNG', mode='RGB'):
    b = io.BytesIO()
    Image.effect_noise(size, 60).convert(mode).save(b, fmt)
    code, m = call('/api/media?name=' + name, b.getvalue())
    assert code == 200, m
    return m

def video(name='clip.mp4', mb=9):
    code, m = call('/api/media?name=' + name, os.urandom(mb * 1024 * 1024))
    assert code == 200, m
    m['duration'] = 12.0
    return m

def post(text, media=(), x=True, fb=True, ig=True, **extra):
    ig_on = {'on': ig, 'text': extra.pop('ig_text', None), 'fmt': extra.pop('fmt', 'feed'), 'fit': extra.pop('fit', 'pad')}
    return {'text': text, 'media': list(media), 'per': {'x': {'on': x, 'text': None}, 'facebook': {'on': fb, 'text': None}, 'instagram': ig_on}, **extra}

def done(pid, wait=40):
    end = time.time() + wait
    while time.time() < end:
        p = call('/api/posts/' + pid)[1]
        if p['status'] != 'posting': return p
        time.sleep(0.2)
    raise TimeoutError(pid)

def publish(p):
    code, r = call('/api/publish', p)
    assert code == 200, r
    return done(r['id'])

def units():
    rfc = {'file': 'vacation.jpg', 'size': 'original', 'oauth_consumer_key': 'dpf43f3p2l4k3l03', 'oauth_token': 'nnch734d00sl2jdk',
           'oauth_signature_method': 'HMAC-SHA1', 'oauth_timestamp': '137131202', 'oauth_nonce': 'chapoH'}
    sig = P.oauth1_sign('GET', 'http://photos.example.net/photos', rfc, 'kd94hf93k423kf44', 'pfkkdhi9sl3r4s00')
    ok('OAuth 1.0a matches the example in RFC 5849', sig == 'MdpQcU8iPSUjWoN/UDMsK2sui9I=', sig)
    ok('X counts Greek as 1 each', P.x_length('Ράλλυ Ακρόπολις') == 15)
    ok('X counts a link as 23', P.x_length('Look https://www.powerslideblog.com/stats!') == 29, P.x_length('Look https://www.powerslideblog.com/stats!'))
    ok('X counts a bare domain as 23', P.x_length('powerslideblog.com') == 23)
    ok('X counts an emoji as 2', P.x_length('🏁') == 2 and P.x_length('👩‍🔧') == 2)
    ok('Link detection ignores plain sentences', not P.has_url('It was fast. Really fast.') and P.has_url('see powerslideblog.com'))
    wide = Image.new('RGB', (3000, 1000))
    tall = Image.new('RGB', (1000, 3000))
    ok('Padding a wide picture brings it to 1.91', abs(P.fit_ratio(wide, .8, 1.91, 'pad').width / P.fit_ratio(wide, .8, 1.91, 'pad').height - 1.91) < .01)
    ok('Cropping a tall picture brings it to 0.8', abs(P.fit_ratio(tall, .8, 1.91, 'crop').width / P.fit_ratio(tall, .8, 1.91, 'crop').height - .8) < .01)

def main():
    units()
    data = tempfile.mkdtemp(prefix='hubtest')
    mock = subprocess.Popen([sys.executable, os.path.join(HERE, 'mock_apis.py'), str(MOCK)], stdout=subprocess.DEVNULL)
    hub = subprocess.Popen([sys.executable, os.path.join(ROOT, 'hub.py'), '--port', str(HUB), '--data', data, '--mock', API, '--no-browser'], stdout=subprocess.DEVNULL)
    time.sleep(2)
    try: scenarios(data)
    finally:
        hub.kill(); mock.kill(); hub.wait(); mock.wait()
        shutil.rmtree(data, ignore_errors=True)
    print(f'\n{sum(results)} of {len(results)} passed')
    sys.exit(0 if all(results) else 1)

def scenarios(data):
    s = call('/api/state')[1]
    ok('Starts in test mode', s['settings']['test_mode'] is True)

    # test mode
    pic = image((1080, 1350), 'graphic.png')
    p = publish(post('A test post', [pic]))
    ok('Test mode finishes', p['status'] == 'done' and p['test'], p)
    ok('Test mode makes no outside calls', log() == [], log())

    # safety
    ok('Another website is refused', call('/api/settings', {'test_mode': False}, headers={'Origin': 'https://evil.example'})[0] == 403)
    ok('A cross-site request is refused', call('/api/state', headers={'Sec-Fetch-Site': 'cross-site'})[0] == 403)
    ok('A rebinding Host is refused', call('/api/state', headers={'Host': 'evil.example'})[0] == 403)
    ok('The test-mode setting did not change', call('/api/state')[1]['settings']['test_mode'] is True)
    ok('A path outside the media folder is refused', call('/media/..%2Fsettings.json')[0] in (403, 404))

    # accounts
    code, _ = call('/api/connect/x', {'api_key': 'wrong', 'api_secret': 'test-secret', 'access_token': 'test-token', 'access_secret': 'test-token-secret'})
    ok('Wrong X keys are rejected', code >= 400)
    code, a = call('/api/connect/x', {'api_key': 'test-key', 'api_secret': 'test-secret', 'access_token': 'test-token', 'access_secret': 'test-token-secret'})
    ok('X connects', code == 200 and a['x']['name'] == '@PowerslideMedia', a)
    code, d = call('/api/connect/meta', {'app_id': '1', 'app_secret': 'app-secret-value', 'token': 'short'})
    ok('Meta lists the Page', code == 200 and d['pages'][0]['ig'] == 'powerslidemedia', d)
    ok('The Page token is not sent to the page', 'page-token' not in json.dumps(d))
    code, a = call('/api/connect/page', {'id': '1111'})
    ok('Facebook and Instagram connect', a['facebook']['connected'] and a['instagram']['connected'] and a['facebook']['expires'] == 0, a)
    blob = open(os.path.join(data, 'secrets.bin'), 'rb').read()
    ok('Keys are encrypted on disk', b'test-secret' not in blob and b'page-token' not in blob and b'app-secret-value' not in blob)
    ok('Keys never reach the browser', not any(k in json.dumps(call('/api/state')[1]) for k in ('test-secret', 'page-token', 'app-secret-value')))
    ok('Connection check reports the Instagram quota', call('/api/health', {})[1].get('quota') == 50)
    call('/api/settings', {'test_mode': False})

    # text only
    n = len(tweets())
    p = publish(post('Text only post', ig=False))
    ok('Text post goes to X and Facebook', p['status'] == 'done' and len(tweets()) == n + 1 and meta('/1111/feed'), p)
    ok('The X link is right', p['results']['x']['url'].startswith('https://x.com/PowerslideMedia/status/'))
    code, r = call('/api/publish', post('No picture'))
    ok('Instagram without a picture is stopped', code == 400 and 'picture' in r['error'], r)
    c = call('/api/check', post('See powerslideblog.com', x=True, fb=False, ig=False))[1]
    ok('A link shows the $0.20 price', c['x']['cost'] == 0.2 and c['x']['count'] == 27, c)
    code, r = call('/api/publish', post('x' * 281, fb=False, ig=False))
    ok('Over 280 is stopped', code == 400, r)
    own = post('Long main text ' * 30, ig=False, fb=False)
    own['per']['x']['text'] = 'Short for X'
    p = publish(own)
    ok('A platform can have its own text', tweets()[-1]['body']['text'] == 'Short for X', tweets()[-1])

    # one picture, wide, so Instagram needs it fitted
    wide = image((2400, 800), 'wide.png')
    p = publish(post('One wide picture', [wide]))
    ok('One picture goes everywhere', p['status'] == 'done', p['results'])
    w, h = meta('/2222/media')[-1]['size']
    ok('Instagram gets a fitted JPEG', abs(w / h - 1.91) < .02 and w <= 1440, (w, h))
    ok('Instagram address keeps its query string', 'oh=a&oe=b' in meta('/2222/media')[-1]['fields']['image_url'])
    ok('The Instagram link comes back', p['results']['instagram']['url'].startswith('https://www.instagram.com/p/'), p['results'])
    ok('The helper photo is deleted from the Page', any(c.get('method') == 'DELETE' for c in log()))
    ok('The real Facebook photo has the caption', any(c['fields'].get('caption') == 'One wide picture' for c in meta('/1111/photos')))

    # a big 2x export has to shrink
    big = image((2160, 2700), 'big.png')
    p = publish(post('Big export', [big], x=False, fb=False))
    w, h = meta('/2222/media')[-1]['size']
    ok('A 2x export shrinks to 1440 wide', p['status'] == 'done' and (w, h) == (1440, 1800), (w, h, p['results']))

    # Story
    p = publish(post('', [image((1080, 1920), 'story.png')], x=False, fb=False, fmt='story'))
    last = meta('/2222/media')[-1]
    ok('A Story goes out with no caption', p['status'] == 'done' and last['fields']['media_type'] == 'STORIES' and 'caption' not in last['fields'], last)

    # carousel
    pics = [image((1080, 1350), f'c{i}.png') for i in range(3)]
    before = len(meta('/2222/media'))
    p = publish(post('Three pictures', pics))
    made = meta('/2222/media')[before:]
    ok('Carousel goes everywhere', p['status'] == 'done', p['results'])
    ok('Carousel has three parts and a parent with the caption', len(made) == 4 and made[-1]['fields'].get('caption') == 'Three pictures' and made[-1]['fields'].get('media_type') == 'CAROUSEL', made)
    ok('Facebook gets all three', sum(k.startswith('attached_media') for k in meta('/1111/feed')[-1]['fields']) == 3)
    ok('X gets all three', len(tweets()[-1]['body']['media']['media_ids']) == 3)
    code, r = call('/api/publish', post('Too many', [image((800, 800), f'n{i}.png') for i in range(5)], fb=False, ig=False))
    ok('Five pictures on X are stopped', code == 400, r)

    # video
    clip = video()
    p = publish(post('A video', [clip]))
    ok('Video goes everywhere', p['status'] == 'done', p['results'])
    ok('X takes the video in chunks', sum('append' in c.get('x', '') for c in log()) == 3)
    ok('Instagram takes the whole file directly', [c for c in log() if 'rupload' in c][-1]['bytes'] == 9 * 1024 * 1024)
    code, r = call('/api/publish', post('Both', [pic, clip]))
    ok('Pictures and video together are stopped', code == 400, r)

    # one platform fails
    call('/__fail?key=ig_publish&mode=error', base=API)
    n = len(tweets())
    p = publish(post('Instagram breaks', [pic]))
    ok('One failure leaves the others posted', p['status'] == 'partial' and p['results']['x']['state'] == 'posted' and p['results']['instagram']['state'] == 'failed', p['results'])
    gone = sum(c.get('method') == 'DELETE' for c in log())
    call('/__fail?key=ig_publish&mode=error', base=API)
    publish(post('Instagram breaks alone', [pic], x=False, fb=False))
    ok('The helper photo is cleaned up after a failure', sum(c.get('method') == 'DELETE' for c in log()) == gone + 1)
    code, r = call(f'/api/publish', {**post('Same again', [pic]), 'id': p['id']})
    ok('A post that went out cannot be sent again by mistake', code == 400, r)
    code, _ = call(f'/api/posts/{p["id"]}/retry', {})
    p = done(p['id'])
    ok('Retry only re-sends the failed platform', p['status'] == 'done' and len(tweets()) == n + 1, (p['status'], len(tweets()), n))

    # the connection drops on the final step
    call('/__fail?key=x_post&mode=drop', base=API)
    p = publish(post('Maybe out', fb=False, ig=False))
    ok('A dropped connection is reported as not sure', p['status'] == 'partial' and p['results']['x']['state'] == 'unsure', p['results'])
    code, r = call(f'/api/posts/{p["id"]}/retry', {})
    ok('Not-sure posts are not retried without asking', code == 400, r)
    code, r = call(f'/api/posts/{p["id"]}/retry', {'unsure': True})
    p = done(p['id'])
    ok('They can be retried once you confirm', p['status'] == 'done', p['results'])

    # double press
    a = call('/api/publish', post('Pressed twice', [clip], fb=False, ig=False))[1]
    second = call(f'/api/posts/{a["id"]}/now', {})
    ok('A second press while posting is refused', second[0] == 400, second)
    done(a['id'])

    # schedule
    n = len(tweets())
    code, r = call('/api/posts', {**post('Scheduled', ig=False), 'when': int(time.time()) + 3, 'schedule': True})
    ok('A post can be scheduled', code == 200 and r['status'] == 'scheduled', r)
    ok('It waits for its time', len(tweets()) == n)
    p = None
    for _ in range(30):
        p = call('/api/posts/' + r['id'])[1]
        if p['status'] == 'done': break
        time.sleep(0.5)
    ok('It goes out by itself', p['status'] == 'done' and len(tweets()) == n + 1, p)
    code, r = call('/api/posts', {**post('Past', ig=False), 'when': int(time.time()) - 5, 'schedule': True})
    ok('A time in the past is refused', code == 400, r)
    code, r = call('/api/posts', {**post('Stale', ig=False), 'when': int(time.time()) + 1, 'schedule': True})
    f = os.path.join(data, 'posts', r['id'] + '.json')
    j = json.load(open(f, encoding='utf8'))
    j['when'] = int(time.time()) - 3600
    json.dump(j, open(f, 'w', encoding='utf8'))
    time.sleep(7)
    n2 = len(tweets())
    q = call('/api/posts/' + r['id'])[1]
    ok('A post an hour late is held back', q['status'] == 'missed' and n2 == n + 1, (q['status'], n2, n))

    # drafts and clean up
    code, r = call('/api/posts', post('A draft', [pic]))
    ok('A draft saves', code == 200 and r['status'] == 'draft')
    ok('A draft can be deleted', call('/api/posts/' + r['id'], method='DELETE')[0] == 200)
    code, a = call('/api/disconnect', {'platform': 'x'})
    ok('X disconnects', not a['x']['connected'])
    code, r = call('/api/publish', post('After disconnect', fb=False, ig=False))
    ok('A disconnected platform is stopped', code == 400, r)
    leftovers = [d for d in os.listdir(os.path.join(data, 'work'))]
    ok('Working files are cleaned up', not leftovers, leftovers)

if __name__ == '__main__':
    main()
